<?php
$season=array("summer","winter","monsoon");
echo "season are: $season[0],$season[1],$season[2]";
echo'<br/>';
echo count($season);
echo '<br/>';
sort($season);
foreach($season as $s){
    echo "$s<br/>";
}
echo'<br/>';
$reverseseason=array_reverse($season);
foreach($reverseseason as $s){
    echo "$s<br/>";
}
echo '<br/>';

$key=array_search("winter",$season);
echo $key;

echo '<br/>';

$name=array("sonu"=>"01","monu"=>"02","dholu"=>"03","bholu"=>"04");
print_r(array_change_key_case($name,CASE_UPPER));
echo '<br/>';
print_r(array_chunk($name,2));

echo'<br/>';

$name1=array("sonu","monu","dholu","bholu");
$name2=array("sonu","smith","shashank","bholu");
$name3=array_intersect($name1,$name2);
foreach($name3 as $n){
    echo "$n<br/>";
}
echo '<br/>';

function userfunction($x){
    if($x==="virat") 
    {
        return "kapil";
    }
    return $x;
    }
$a=array("sachin","virat","dhoni");
print_r(array_map("userfunction",$a));
echo '<br/>';

function userfunction1($value,$key)
{
    echo "The key $key has a value $value <br/>";

}
$tech=array("a"=>"yt","b"=>"wt","c"=>"insta");
array_walk($tech,"userfunction1");
echo '<br/>';

function myfunction($v)
{
    return $v*$v;
}
$array =array(1,2,3,4,5,6);
print_r(array_map("myfunction",$array));

?>