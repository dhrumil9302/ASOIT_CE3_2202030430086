<?php
$servername = "localhost";
$username = "root";
$password = "";
$Database = "form";

$conn = new mysqli($servername, $username, $password, $Database);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else{
  echo "Connected successfully";
}


$first_name = $_REQUEST['F_name'];
$last_name = $_REQUEST['L_name'];
$ER_No = $_REQUEST['ErNo'];
$Sem = $_REQUEST['sem'];
$Branch = $_REQUEST['Branch'];
$Gender = $_REQUEST['Gender'];
$Mobile_No = $_REQUEST['MoNo'];
$City = $_REQUEST['City'];

$Query = "INSERT INTO Student VALUES ('$first_name', '$last_name', '$ER_No', '$Sem' ,'$Branch', '$Gender' , '$Mobile_No', '$City' )";


   if(mysqli_query($conn, $Query)){
        echo "Successfull save";
   }else{
    echo "ERROR $Query."
            .mysqli_error($conn);
   }
   
   mysqli_close($conn);
?>