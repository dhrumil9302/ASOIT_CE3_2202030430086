
        <?php
        $text = "welcome";
        $var = "10";
        echo "$text";
        echo "<br>";
        echo "$var";
        ?>
  