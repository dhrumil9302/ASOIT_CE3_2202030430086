<?php
$servername = "localhost";
$username = "root";
$password = "";
$Database = "form";

$conn = new mysqli($servername, $username, $password, $Database);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else{
  echo "Connected successfully";
}


$Query = "INSERT INTO Student (Id,Name, Branch, Sem) VALUES ('2202030430086', 'Dhrumil', 'CE', '5')";
$Query = "INSERT INTO Student (Id,Name, Branch, Sem) VALUES ('2202030430082', 'Ghanshyam', 'CE', '5')";

$result =$conn->multi_query($Query);


    if($conn->error){

      echo $conn->error;
  
  }else {
      echo '<br>';
      echo 'New record created successfully';
  }
     
?>