console.log('Hii I am Harsh Panchal');
console.log('This is an example of Node JS');