$(document).ready(function() {
    $('#feedbackForm').submit(function(event) {
      event.preventDefault();
      
      // Clear any previous error messages
      $('.error-message').remove();
      
      // Get form data
      var name = $('#name').val();
      var email = $('#email').val();
      var message = $('#message').val();
      
      // Validate form data
      if (!name) {
        $('#name').addClass('shake').after('<div class="error-message">Please enter your name</div>');
        return;
      }
      
      if (!email) {
        $('#email').addClass('shake').after('<div class="error-message">Please enter your email</div>');
        return;
      }
      
      if (!message) {
        $('#message').addClass('shake').after('<div class="error-message">Please enter your message</div>');
        return;
      }
      
      // Simulate form submission (replace with your own code)
      setTimeout(function() {
        $('#feedbackForm').trigger('reset');
        $('#name, #email, #message').removeClass('shake');
        $('.form-group').append('<div class="success-message">Thank you for your feedback!</div>');
      }, 2000);
    });
  });
  