<!DOCTYPE html>
<html>
<body>

<?php
$x = 10; 
echo nl2br($x."\n"); 
$y = 6;
echo nl2br($y."\n");

echo "Addition:", $x + $y;
echo "<br>";
echo "Multiplication:",$x * $y;
echo "<br>";
echo "Subtraction:", $x - $y;
echo "<br>";
echo "Multuplication:", $x * $y;
echo "<br>";

?>  

</body>
</html>
