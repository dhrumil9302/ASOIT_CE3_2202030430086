<!DOCTYPE html>
<html>
    <head>
        <title>Form HTML</title>
    </head>
    <body  style="background-color: lightblue">
        <form action="form.php" method="post">
        <center>
        <div><h1><center>Silver Oak University</center></h1></div>
            <label>First Name :</label>
            <input type="text" name="F_name" placeholder="Enter your First name">
            <br/><br/>
            <label>Last Name :</label>
            <input type="text" name="L_name" placeholder="Enter your Last name">
            <br/><br/>
            <label>Enrollment No :</label>
            <input type="text" name="ErNo" placeholder="Enter your Enrollment No">
            <br/><br/>
            <label>Semester :</label>
            <input type="text" name="sem" placeholder="Enter your Semester">
            <br/><br/>
            <label>Branch :</label>
            <input type="text" name="Branch" placeholder="Enter your Branch">
            <br/><br/>
            <label>Gender :</label>
            <input type="text" name="Gender" placeholder="Enter your Gender">
            <br/><br/>
            <label>Mobile No :</label>
            <input type="text" name="MoNo" placeholder="Enter your Mobile Number">
            <br/><br/>
            <label>City :</label>
            <input type="text" name="City" placeholder="Enter your City">
            <br/><br/>
            <input type="submit" value="Submit">
        </center>
        </form>
    </body>
</html>